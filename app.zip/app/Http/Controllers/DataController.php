<?php

namespace App\Http\Controllers;
//paginacijasi
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;


use Illuminate\Http\Request;
use App\Models\Data;
use App\Models\Roles;

class DataController extends Controller
{
    //

    public function showAllData() {
        $data = new Data();
        // dd($data->all());
        // return view('allData', ['data'=>$data->orderBy('id','asc')->get()]);
        //  return view('allData', ['data'=>DB::table('data_temp')->paginate(2)]);
        return view('allData', ['data' => DB::table('data_temp')->paginate(1)]);
    
    }

        public function showAllRoles()
    {
        $roles = Roles::orderBy('RoleID', 'asc')->get();
        // return view('allRoles', ['roles' => $roles]);
        return view('allRoles', ['roles' => DB::table('Roles')->orderBy('RoleID', 'asc')->paginate(2)]);
    }


public function delete($id) {

    Data::find($id)->delete();
    return redirect()->to('/data/allData')->with('success', 'Ieraksts bija izdzests');

}



public function edit($id) {

    //Data::find($id);
    // return redirect()->to('/data/allData')->with('success', 'Ieraksts bija izdzests');
    // return $id;
    $data = new Data;
    return view('edit', ['data'=>$data->find($id)]);

}


public function editSubmit(Request $dati, $id)
{

        $validation = $dati->validate([
        'name' => 'required|min:3|max:20',
        'email' => 'required|email|max:20',
        'subject' => 'required|min:3|max:20',
        'message' => 'required|min:3|max:1024'
    ])  ;    
    
    $data = Data::find($id);
    $data->name = $dati->input('name');
        $data->email = $dati->input('email');
    $data->subject = $dati->input('subject');
    $data->message = $dati->input('message');
    $data->save();
    // return redirect('/data/allData')->with('succes','Veismigi izdarits');
    return view('details', ['data'=>$data->find($id)]);  


}


public function deleteR($id) {

    Roles::find($id)->delete();                                                        
    return redirect()->to('/data/allRoles')->with('success1', 'Ieraksts bija izdzests');;                                                        
                                                        
}                                                        
                                                        
public function details($id) {                                                        
    $dati = new Data;                                                        
    return view('details', ['data'=>$dati->find($id)]);                                                        
}                                                        
                                                        
                                                        
public function details_r($id) {                                                        
    $roles = new Roles;                                                        
    return view('detailsRoles', ['roles'=>$roles->find($id)]);                                                        
}                                                        
                                                        
                                                        
//jauna ieraksta pievienosana                                                        
public function newSubmit(Request $dati) {                                                        
    // return "Viss labi!";                                                        
  // return dd($dati->all());                                                        
    //  return ($dati->input('subject'));   
    $validation = $dati->validate([
        'name' => 'required|min:3|max:20',
        'email' => 'required|email|max:20',
        'subject' => 'required|min:3|max:20',
        'message' => 'required|min:3|max:1024'
    ])  ;    
    
    $data = new Data;
    $data->name = $dati->input('name');
        
    $data->email = $dati->input('email');
    $data->subject = $dati->input('subject');
    $data->message = $dati->input('message');
    $data->save();
    // return redirect('/contacts')->with('succes','Veismigi izdarits');

      return redirect()->to('/data/allData')->with('success', 'Veiksmīgi izdarīts');
}                                                        
                                                        
          

public function newRole(Request $dati) {                                                        
    // return "Viss labi!";                                                        
  // return dd($dati->all());                                                        
    //  return ($dati->input('subject'));   
    $validation = $dati->validate([
        'RoleName' => 'required|min:2|max:20',
    ])  ;    
              $roles = new Roles;
    $roles->RoleName = $dati->input('RoleName');
        

    $roles->save();
    // return redirect('/contacts')->with('succes','Veismigi izdarits');

      return redirect()->to('/data/allRoles')->with('success', 'Veiksmīgi izdarīts');                                              
                      
    
}                                                        
    
public function editRoles($id) {

    //Data::find($id);
    // return redirect()->to('/data/allData')->with('success', 'Ieraksts bija izdzests');
    // return $id;
    $roles = new Roles;
    return view('editroles', ['roles'=>$roles->find($id)]);

}

public function editRolesSubmit(Request $dati, $id)
{

        $validation = $dati->validate([
        'RoleName' => 'required|min:2|max:20',
    ])  ;    
    
    $roles = Roles::find($id);
    $roles->RoleName = $dati->input('RoleName');
        // $data->email = $dati->input('email');
    // $data->subject = $dati->input('subject');
    // $data->message = $dati->input('message');
    $roles->save();
    // return redirect('/data/allData')->with('succes','Veismigi izdarits');
    // return view('detailsRoles', ['roles'=>$roles->find($id)]);
    return redirect()->to('/data/allRoles')->with('success', 'Veiksmīgi izdarīts'); 


}


}