<!DOCTYPE html>
<html>
<head>
<title>Page Title</title>
</head>
<body>

<h1>Par mums</h1>
<p>Infromacija par mums.</p>
<h2>Par mums <H2></H2></h2>
</body>
</html>


<!-- // tas ir layout, as a template in word press. -->