<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DataController;

// Route::get('/', function () {
//     return view('welcome');
// });



Route::get('/', function () {
    return view('home');
});

Route::get('/about', function () {
    return view('about');
});


Route::get('/contacts', function () {
    return view('contacts');
});




Route::get('/neeks', function () {
    return view('neeks');
});

Route::get('/neeks2', function () {
    return view('about');
});


Route::get('/roles/addRole', function () {
    return view('addRole');
});

Route::get('/data', function () {
    return view('data');
});

Route::get('/data/allData', 'App\Http\Controllers\DataController@showAllData'); 

Route::get('/data/allRoles', 'App\Http\Controllers\DataController@showAllRoles');
// {
//     return view('allData');
// });


//marsruts delete data element from data_temp
Route::get('/data/all/{id}/delete', 'App\Http\Controllers\DataController@delete'); 

Route::get('/roles/all/{id}/delete', 'App\Http\Controllers\DataController@deleteR'); 


//saite detalizetai informacijai par datu elementu
Route::get('/data/all/{id}/Detalizeti', 'App\Http\Controllers\DataController@details')->name('data-details');


// jauns zinojums vai elements
// Route::post('/data/newSubmit', function () {
//     return dd(Request()::all());
// });

Route::post('/data/newSubmit', 'App\Http\Controllers\DataController@newSubmit');

Route::post('/roles/newRole', 'App\Http\Controllers\DataController@newRole');
//saite detalizetai informacijai par datu elementu
Route::get('/roles/all/{id}/details_r', 'App\Http\Controllers\DataController@details_r')->name('roles-details');





Route::get('/roles/all/{id}/edit', 'App\Http\Controllers\DataController@editRoles');

Route::post('/roles/{RoleID}/editRoles', 'App\Http\Controllers\DataController@editRolesSubmit');









Route::get('/data/all/{id}/edit', 'App\Http\Controllers\DataController@edit');

Route::post('/data/{id}/editSubmit', 'App\Http\Controllers\DataController@editSubmit');



